# Info
- Ver: 2.0.0
- Plugin GamesUI You Can Join Games UI From The Plugin And You Can Edit Command From Config 
- Soon Add Custom Name Game!
- You Can set "true" or "false" JoinCompass From Config (When Player Join Get Compass to Open GamesUI
- *Please do not take it and say it is yours when Plugin By MR Zinkil 2020 COPYRIGHT*

# Commands
- Usage: /games [to OpenUI to Join Games]
- Usage: /ginfo [info Plugin]

# Config
- You Can Change Join Command From Config!
- Don'n Change ver from config to test config!

# Developers
- Created By MR Zinkil 2020 COPYRIGHT 
- Devs [MR Zinkil]

# YouTube
- [Link Channel]()
